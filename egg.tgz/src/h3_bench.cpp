// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("10k requests over HTTP/3\n", stdout);
  return lionss_run_workload("h3_bench");
}
