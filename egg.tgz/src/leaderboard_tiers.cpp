// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tier cutoffs by percentile\n", stdout);
  return lionss_run_workload("leaderboard_tiers");
}
