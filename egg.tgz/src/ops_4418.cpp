// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Drain the dead-letter queue"); }
int main(){
  announce();
  return lionss_run_workload("ops_4418");
}
