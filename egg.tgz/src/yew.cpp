// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Nest parts on 600x400 sheet");
  std::fflush(stdout);
  return lionss_run_workload("yew");
}
