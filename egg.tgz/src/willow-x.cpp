// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Verify PAdES signature chain"); }
int main(){
  announce();
  return lionss_run_workload("willow-x");
}
