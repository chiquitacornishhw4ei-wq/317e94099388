// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flow-field plot, 1 200 lines"); }
int main(){
  announce();
  return lionss_run_workload("osprey");
}
