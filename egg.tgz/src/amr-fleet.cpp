// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Multi-agent path finding, 8 robots\n", stdout);
  return lionss_run_workload("amr-fleet");
}
