// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate 50k synthetic rows\n", stdout);
  return lionss_run_workload("synthgen_tabular");
}
