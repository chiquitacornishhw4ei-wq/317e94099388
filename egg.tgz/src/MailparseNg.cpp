// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Parse headers and MIME tree"); }
int main(){
  announce();
  return lionss_run_workload("MailparseNg");
}
