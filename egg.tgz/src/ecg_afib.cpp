// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("AF detection from RR irregularity\n", stdout);
  return lionss_run_workload("ecg_afib");
}
