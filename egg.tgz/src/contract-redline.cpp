// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Redline clauses between drafts");
  std::fflush(stdout);
  return lionss_run_workload("contract-redline");
}
