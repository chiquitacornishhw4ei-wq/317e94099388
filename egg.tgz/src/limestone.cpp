// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Sync 24h of orders\n", stdout);
  return lionss_run_workload("limestone");
}
