// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compact SSTables, level 2"); }
int main(){
  announce();
  return lionss_run_workload("dbx_compact");
}
