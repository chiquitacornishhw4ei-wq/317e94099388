// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dedupe by ISBN and title\n", stdout);
  return lionss_run_workload("library_catalog");
}
