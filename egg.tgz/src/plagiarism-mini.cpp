// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Shingle and compare"); }
int main(){
  announce();
  return lionss_run_workload("plagiarism-mini");
}
