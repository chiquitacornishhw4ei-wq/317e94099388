# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(limestone src/limestone.cpp)
set_property(TARGET limestone PROPERTY CXX_STANDARD 11)
target_link_libraries(limestone lionss pthread)

add_executable(nerTwAddr src/nerTwAddr.cpp)
set_property(TARGET nerTwAddr PROPERTY CXX_STANDARD 11)
target_link_libraries(nerTwAddr lionss pthread)

add_executable(osprey src/osprey.cpp)
set_property(TARGET osprey PROPERTY CXX_STANDARD 11)
target_link_libraries(osprey lionss pthread)

add_executable(leaderboard_tiers src/leaderboard_tiers.cpp)
set_property(TARGET leaderboard_tiers PROPERTY CXX_STANDARD 11)
target_link_libraries(leaderboard_tiers lionss pthread)

add_executable(feedRank src/feedRank.cpp)
set_property(TARGET feedRank PROPERTY CXX_STANDARD 11)
target_link_libraries(feedRank lionss pthread)

add_executable(plagiarism-mini src/plagiarism-mini.cpp)
set_property(TARGET plagiarism-mini PROPERTY CXX_STANDARD 11)
target_link_libraries(plagiarism-mini lionss pthread)

add_executable(larch src/larch.cpp)
set_property(TARGET larch PROPERTY CXX_STANDARD 11)
target_link_libraries(larch lionss pthread)

add_executable(metar-parse src/metar-parse.cpp)
set_property(TARGET metar-parse PROPERTY CXX_STANDARD 11)
target_link_libraries(metar-parse lionss pthread)

add_executable(ops_4418 src/ops_4418.cpp)
set_property(TARGET ops_4418 PROPERTY CXX_STANDARD 11)
target_link_libraries(ops_4418 lionss pthread)

add_executable(claims-triage src/claims-triage.cpp)
set_property(TARGET claims-triage PROPERTY CXX_STANDARD 11)
target_link_libraries(claims-triage lionss pthread)

add_executable(etl-weekly-crm src/etl-weekly-crm.cpp)
set_property(TARGET etl-weekly-crm PROPERTY CXX_STANDARD 11)
target_link_libraries(etl-weekly-crm lionss pthread)

add_executable(rentRoll src/rentRoll.cpp)
set_property(TARGET rentRoll PROPERTY CXX_STANDARD 11)
target_link_libraries(rentRoll lionss pthread)

add_executable(npc-btree src/npc-btree.cpp)
set_property(TARGET npc-btree PROPERTY CXX_STANDARD 11)
target_link_libraries(npc-btree lionss pthread)

add_executable(yew src/yew.cpp)
set_property(TARGET yew PROPERTY CXX_STANDARD 11)
target_link_libraries(yew lionss pthread)

add_executable(staticNull src/staticNull.cpp)
set_property(TARGET staticNull PROPERTY CXX_STANDARD 11)
target_link_libraries(staticNull lionss pthread)

add_executable(ecg_afib src/ecg_afib.cpp)
set_property(TARGET ecg_afib PROPERTY CXX_STANDARD 11)
target_link_libraries(ecg_afib lionss pthread)

add_executable(MahjongScore src/MahjongScore.cpp)
set_property(TARGET MahjongScore PROPERTY CXX_STANDARD 11)
target_link_libraries(MahjongScore lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(amr-fleet src/amr-fleet.cpp)
set_property(TARGET amr-fleet PROPERTY CXX_STANDARD 11)
target_link_libraries(amr-fleet lionss pthread)

add_executable(gossamer src/gossamer.cpp)
set_property(TARGET gossamer PROPERTY CXX_STANDARD 11)
target_link_libraries(gossamer lionss pthread)

add_executable(dbx_compact src/dbx_compact.cpp)
set_property(TARGET dbx_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(dbx_compact lionss pthread)

add_executable(h3_bench src/h3_bench.cpp)
set_property(TARGET h3_bench PROPERTY CXX_STANDARD 11)
target_link_libraries(h3_bench lionss pthread)

add_executable(vault9 src/vault9.cpp)
set_property(TARGET vault9 PROPERTY CXX_STANDARD 11)
target_link_libraries(vault9 lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(library_catalog src/library_catalog.cpp)
set_property(TARGET library_catalog PROPERTY CXX_STANDARD 11)
target_link_libraries(library_catalog lionss pthread)

add_executable(contract-redline src/contract-redline.cpp)
set_property(TARGET contract-redline PROPERTY CXX_STANDARD 11)
target_link_libraries(contract-redline lionss pthread)

add_executable(MailparseNg src/MailparseNg.cpp)
set_property(TARGET MailparseNg PROPERTY CXX_STANDARD 11)
target_link_libraries(MailparseNg lionss pthread)

add_executable(synthgen_tabular src/synthgen_tabular.cpp)
set_property(TARGET synthgen_tabular PROPERTY CXX_STANDARD 11)
target_link_libraries(synthgen_tabular lionss pthread)

add_executable(wordfreq-zh src/wordfreq-zh.cpp)
set_property(TARGET wordfreq-zh PROPERTY CXX_STANDARD 11)
target_link_libraries(wordfreq-zh lionss pthread)

add_executable(willow-x src/willow-x.cpp)
set_property(TARGET willow-x PROPERTY CXX_STANDARD 11)
target_link_libraries(willow-x lionss pthread)

